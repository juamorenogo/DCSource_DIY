*PADS-LIBRARY-PART-TYPES-V9*

UCC38C43DGKR SOP65P490X110-8N I ANA 7 1 0 0 0
TIMESTAMP 2026.05.26.00.06.48
"Mouser Part Number" 595-UCC38C43DGKR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/UCC38C43DGKR?qs=zqbRmZ%252BfZD%252BXDziCZUmxYw%3D%3D
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" UCC38C43DGKR
"Description" BiCMOS Low-Power Current Mode PWM Controller
"Datasheet Link" http://www.ti.com/lit/gpn/UCC38C43
"Geometry.Height" 1.1mm
GATE 1 8 0
UCC38C43DGKR
1 0 U COMP
2 0 U FB
3 0 U CS
4 0 U RT/CT
8 0 U VREF
7 0 U VDD
6 0 U OUT
5 0 U GND

*END*
*REMARK* SamacSys ECAD Model
2017501/1895263/2.50/8/3/Integrated Circuit
