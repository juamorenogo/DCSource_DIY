*PADS-LIBRARY-PART-TYPES-V9*

AMRM00101040150MA1 INDPM116102X400N I IND 7 1 0 0 0
TIMESTAMP 2026.07.12.05.33.03
"Mouser Part Number" 
"Mouser Price/Stock" 
"Manufacturer_Name" Yageo Group
"Manufacturer_Part_Number" AMRM00101040150MA1
"Description" 15 H Unshielded Inductor 6 A 45mOhm Max Nonstandard
"Datasheet Link" 
"Geometry.Height" 4mm
GATE 1 2 0
AMRM00101040150MA1
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
18685841/1895263/2.50/2/4/Inductor
