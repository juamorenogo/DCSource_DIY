*PADS-LIBRARY-PART-TYPES-V9*

4300.0104 43000104 I CON 6 1 0 0 0
TIMESTAMP 2026.07.12.04.56.44
"Mouser Part Number" 693-4300.0104
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Schurter/4300.0104?qs=rrS6PyfT74f9dYJbiFYBTw%3D%3D
"Manufacturer_Name" SCHURTER
"Manufacturer_Part_Number" 4300.0104
"Description" POWER ENTRY, PLUG, 2.5A, 250V, QC; Product Range:2570 Series; Gender:Plug; Voltage Rating:250V; Current Rating:2.5A; Connector Mounting:Panel Mount; Contact Termination Type:Quick Connect RoHS Compliant: Yes
"Datasheet Link" https://us.schurter.com/bundles/snceschurter/epim/_ProdPool_/newDS/en/typ_2570.pdf
GATE 1 4 0
4300.0104
1 0 U 1
2 0 U 2
MH1 0 U MH1
MH2 0 U MH2

*END*
*REMARK* SamacSys ECAD Model
1145539/1895263/2.50/4/2/Connector
