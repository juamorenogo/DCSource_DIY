*PADS-LIBRARY-PART-TYPES-V9*

TPS54302DDCR SOT95P280X110-6N I ANA 7 1 0 0 0
TIMESTAMP 2026.07.12.01.50.01
"Mouser Part Number" 595-TPS54302DDCR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/TPS54302DDCR?qs=zEmsApcVOkUXM7UP0GSO2g%3D%3D
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" TPS54302DDCR
"Description" Conv DC-DC 4.5V to 28V Synchronous Step Down Single-Out 0.6V to 26V 3A 6-Pin TSOT-23 T/R
"Datasheet Link" http://www.ti.com/general/docs/suppproductinfo.tsp?distId=10&gotoUrl=http%3A%2F%2Fwww.ti.com%2Flit%2Fgpn%2Ftps54302
"Geometry.Height" 1.1mm
GATE 1 6 0
TPS54302DDCR
1 0 U GND
2 0 U SW
3 0 U VIN
6 0 U BOOT
5 0 U EN
4 0 U FB

*END*
*REMARK* SamacSys ECAD Model
5357667/1895263/2.50/6/3/Integrated Circuit
