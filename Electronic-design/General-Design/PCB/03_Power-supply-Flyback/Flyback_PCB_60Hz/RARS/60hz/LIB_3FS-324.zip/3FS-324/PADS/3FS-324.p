*PADS-LIBRARY-PART-TYPES-V9*

3FS-324 3FS324 I XFR 7 1 0 0 0
TIMESTAMP 2026.07.12.01.55.17
"Mouser Part Number" 838-3FS-324
"Mouser Price/Stock" https://www.mouser.com/Search/Refine.aspx?Keyword=838-3FS-324
"Manufacturer_Name" Tamura
"Manufacturer_Part_Number" 3FS-324
"Description" Power Transformers POWER TRANSFORMER
"Datasheet Link" https://componentsearchengine.com/Datasheets/1/3FS-324.pdf
"Geometry.Height" 32.1mm
GATE 1 6 0
3FS-324
1 0 U PRI_1
4 0 U PRI_2
5 0 U SEC_1
6 0 U SEC_2
7 0 U SEC_3
8 0 U SEC_4

*END*
*REMARK* SamacSys ECAD Model
715144/1895263/2.50/6/3/Transformer
