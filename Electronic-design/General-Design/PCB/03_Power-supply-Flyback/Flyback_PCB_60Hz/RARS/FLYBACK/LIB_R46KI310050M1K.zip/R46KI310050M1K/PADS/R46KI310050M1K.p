*PADS-LIBRARY-PART-TYPES-V9*

R46KI310050M1K R46KI310050M1K I CAP 7 1 0 0 0
TIMESTAMP 2026.07.22.17.37.23
"Mouser Part Number" 80-R46KI310050M1K
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/KEMET/R46KI310050M1K/?qs=D0iH%252BVFiYPMp3c4CZzIXlA%3D%3D
"Manufacturer_Name" Yageo Group
"Manufacturer_Part_Number" R46KI310050M1K
"Description" R46 275 VAC, Film, Metallized Polypropylene, Safety, 0.1 uF, 10%, 275 VAC (X2), 560 VDC, 110C, 15mm
"Datasheet Link" https://www.yageogroup.com/content/datasheet/asset/file/KEM_F3093_R46_X2_275_110C
"Geometry.Height" 11.1mm
GATE 1 2 0
R46KI310050M1K
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
662681/1895263/2.50/2/2/Capacitor
