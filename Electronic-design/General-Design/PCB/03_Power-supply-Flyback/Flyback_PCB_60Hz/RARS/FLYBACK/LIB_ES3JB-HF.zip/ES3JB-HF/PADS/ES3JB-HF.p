*PADS-LIBRARY-PART-TYPES-V9*

ES3JB-HF DIOM5235X244N I DIO 7 1 0 0 0
TIMESTAMP 2026.07.26.06.56.40
"Mouser Part Number" 750-ES3JB-HF
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Comchip-Technology/ES3JB-HF?qs=hd1VzrDQEGh59SJw6leQSQ%3D%3D
"Manufacturer_Name" Comchip Technology
"Manufacturer_Part_Number" ES3JB-HF
"Description" Rectifiers RECTIFIER SUPER FAST RECOVERY 600V 3A SMB
"Datasheet Link" https://www.comchiptech.com/admin/files/product/QW-JS017%20ES3AB-HF%20Thru.%20ES3JB-HF%20RevA.pdf
"Geometry.Height" 2.44mm
GATE 1 2 0
ES3JB-HF
1 0 U K
2 0 U A

*END*
*REMARK* SamacSys ECAD Model
13412832/1895263/2.50/2/3/Diode
