*PADS-LIBRARY-PART-TYPES-V9*

STPST5H100SF STPST5H100SF I ANA 6 1 0 0 0
TIMESTAMP 2026.07.26.06.56.28
"Mouser Part Number" 511-STPST5H100SF
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/STMicroelectronics/STPST5H100SF?qs=Jm2GQyTW%2Fbh7VYET2eIYxg%3D%3D
"Manufacturer_Name" STMicroelectronics
"Manufacturer_Part_Number" STPST5H100SF
"Description" Schottky Rectifier, 100 V, 5 A, Single, TO-277A, 3 Pins.
"Datasheet Link" https://www.st.com/resource/en/datasheet/stpst5h100.pdf
GATE 1 3 0
STPST5H100SF
3 0 U K
1 0 U A1
2 0 U A2

*END*
*REMARK* SamacSys ECAD Model
17457287/1895263/2.50/3/2/Schottky Diode with Dual Anode
