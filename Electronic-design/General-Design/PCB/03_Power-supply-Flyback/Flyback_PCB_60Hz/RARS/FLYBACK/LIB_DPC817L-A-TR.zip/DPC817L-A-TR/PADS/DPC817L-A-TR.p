*PADS-LIBRARY-PART-TYPES-V9*

DPC817L-A-TR SOP254P1180X410-4N I ANA 7 1 0 0 0
TIMESTAMP 2026.07.22.21.07.17
"Mouser Part Number" 
"Mouser Price/Stock" 
"Manufacturer_Name" Diodes Incorporated
"Manufacturer_Part_Number" DPC817L-A-TR
"Description" Transistor Output Optocouplers Photo Coupler SLM-4 T&R 2K
"Datasheet Link" https://www.mouser.mx/ProductDetail/Diodes-Incorporated/DPC817L-A-TR?qs=mELouGlnn3fKeXigB%252Bx6BQ%3D%3D
"Geometry.Height" 4.1mm
GATE 1 4 0
DPC817L-A-TR
1 0 U ANODE
2 0 U CATHODE
4 0 U COLLECTOR
3 0 U EMMITER

*END*
*REMARK* SamacSys ECAD Model
21292036/1895263/2.50/4/3/Integrated Circuit
