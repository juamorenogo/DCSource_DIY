*PADS-LIBRARY-PART-TYPES-V9*

750811351 750811351 I XFR 7 1 0 0 0
TIMESTAMP 2026.07.22.21.07.09
"Mouser Part Number" 710-750811351
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Wurth-Elektronik/750811351?qs=J4sk5G6CMwbNsr5I5cpBnA%3D%3D
"Manufacturer_Name" Wurth Elektronik
"Manufacturer_Part_Number" 750811351
"Description" WE-OLLT Offline Flyback Transformers ETD34 THT;   Ui = 85-265V;    Uo1 = 36V/3A;   f = 100kHz
"Datasheet Link" https://www.we-online.com/catalog/datasheet/750811351.pdf
"Geometry.Height" 30.48mm
GATE 1 14 0
750811351
1 0 U NC_1
2 0 U PRI_1
3 0 U PRI_2
4 0 U PRI_3
5 0 U NC_2
6 0 U AUX_1
7 0 U AUX_2
8 0 U PRI_4
9 0 U PRI_5
10 0 U PRI_6
11 0 U NC_3
12 0 U NC_4
13 0 U PRI_7
14 0 U PRI_8

*END*
*REMARK* SamacSys ECAD Model
678774/1895263/2.50/14/2/Transformer
