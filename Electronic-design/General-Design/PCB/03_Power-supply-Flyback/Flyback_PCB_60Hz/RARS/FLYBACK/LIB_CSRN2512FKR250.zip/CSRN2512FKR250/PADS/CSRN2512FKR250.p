*PADS-LIBRARY-PART-TYPES-V9*

CSRN2512FKR250 RESC6432X70N I RES 7 1 0 0 0
TIMESTAMP 2026.07.22.21.07.55
"Mouser Part Number" 
"Mouser Price/Stock" 
"Manufacturer_Name" Stackpole Electronics, Inc.
"Manufacturer_Part_Number" CSRN2512FKR250
"Description" RES CS, 2512, 0.25 ohm, 1%, 2W
"Datasheet Link" https://cs.seielect.com/catalog/SEI-CSR_CSRN.pdf
"Geometry.Height" 0.7mm
GATE 1 2 0
CSRN2512FKR250
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
5017133/1895263/2.50/2/2/Resistor
