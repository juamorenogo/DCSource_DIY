*PADS-LIBRARY-PART-TYPES-V9*

TB002-500-02BE TB002-500-02BE I CON 7 1 0 0 0
TIMESTAMP 2026.07.26.23.47.01
"Mouser Part Number" 490-TB002-500-02BE
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Same-Sky/TB002-500-02BE?qs=vLWxofP3U2x9716kcgva%2Fw%3D%3D
"Manufacturer_Name" Same Sky
"Manufacturer_Part_Number" TB002-500-02BE
"Description" TB002-500 Series - 2~24 Poles, Screw Type, Horizontal, 5.0 Pitch, 22~12 (AWG), Terminal Block Connector
"Datasheet Link" https://www.sameskydevices.com/product/resource/supplyframepdf/tb002-500.pdf
"Geometry.Height" 10.4mm
GATE 1 2 0
TB002-500-02BE
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
12846714/1895263/2.50/2/2/Connector
