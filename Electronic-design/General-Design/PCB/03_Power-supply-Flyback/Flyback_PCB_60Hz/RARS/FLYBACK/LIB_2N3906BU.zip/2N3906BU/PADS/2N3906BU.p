*PADS-LIBRARY-PART-TYPES-V9*

2N3906BU 2N3906BU I TRX 6 1 0 0 0
TIMESTAMP 2026.07.26.23.27.11
"Mouser Part Number" 512-2N3906BU
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/onsemi-Fairchild/2N3906BU?qs=iN0KuJO79Kbn9o7a2lB4uA%3D%3D
"Manufacturer_Name" onsemi
"Manufacturer_Part_Number" 2N3906BU
"Description" These Devices are Pb-Free, Halogen Free/BFR Free and are RoHS Compliant
"Datasheet Link" https://www.onsemi.com/pub/Collateral/2N3906-D.pdf
GATE 1 3 0
2N3906BU
2 0 U B
1 0 U E
3 0 U C

*END*
*REMARK* SamacSys ECAD Model
977683/1895263/2.50/3/2/Transistor BJT PNP
