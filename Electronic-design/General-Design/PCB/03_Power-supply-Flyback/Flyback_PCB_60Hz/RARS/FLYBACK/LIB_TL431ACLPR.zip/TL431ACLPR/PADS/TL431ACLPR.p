*PADS-LIBRARY-PART-TYPES-V9*

TL431ACLPR TL431ACLPR I ANA 7 1 0 0 0
TIMESTAMP 2026.07.22.21.07.25
"Mouser Part Number" 595-TL431ACLPR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/TL431ACLPR?qs=0le1rQK8zxqBxlVXkAYIwg%3D%3D
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" TL431ACLPR
"Description" 1% Accuracy Adjustable Precision Shunt Regulator
"Datasheet Link" http://www.ti.com/lit/gpn/tl431
"Geometry.Height" 5.34mm
GATE 1 3 0
TL431ACLPR
1 0 U REF
2 0 U A
3 0 U K

*END*
*REMARK* SamacSys ECAD Model
182372/1895263/2.50/3/4/Integrated Circuit
