*PADS-LIBRARY-PART-TYPES-V9*

UCC38C43DR SOIC127P600X175-8N I ANA 7 1 0 0 0
TIMESTAMP 2026.07.22.20.43.14
"Mouser Part Number" 595-UCC38C43DR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/UCC38C43DR?qs=zqbRmZ%252BfZD8PGQXkq%2FjeEA%3D%3D
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" UCC38C43DR
"Description" Texas Instruments UCC38C43DR, PWM Current Mode Controller, 0.2 A, 1000 kHz 8-Pin SOIC
"Datasheet Link" http://www.ti.com/lit/gpn/UCC38C43
"Geometry.Height" 1.75mm
GATE 1 8 0
UCC38C43DR
1 0 U COMP
2 0 U FB
3 0 U CS
4 0 U RT/CT
8 0 U VREF
7 0 U VDD
6 0 U OUT
5 0 U GND

*END*
*REMARK* SamacSys ECAD Model
418497/1895263/2.50/8/3/Integrated Circuit
