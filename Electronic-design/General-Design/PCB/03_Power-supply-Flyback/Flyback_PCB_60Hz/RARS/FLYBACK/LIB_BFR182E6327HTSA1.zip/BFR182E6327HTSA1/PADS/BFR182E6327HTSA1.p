*PADS-LIBRARY-PART-TYPES-V9*

BFR182E6327HTSA1 SOT95P240X110-3N I TRX 7 1 0 0 0
TIMESTAMP 2026.07.26.20.28.42
"Mouser Part Number" 
"Mouser Price/Stock" 
"Manufacturer_Name" Infineon
"Manufacturer_Part_Number" BFR182E6327HTSA1
"Description" RF Bipolar Transistors NPN Silicon RF TRANSISTOR
"Datasheet Link" https://www.infineon.com/dgdl/bfr182.pdf?folderId=db3a30431400ef68011425b1354605c1&fileId=db3a30431400ef680114268f4d130640
"Geometry.Height" 1.1mm
GATE 1 3 0
BFR182E6327HTSA1
1 0 U B
2 0 U E
3 0 U C

*END*
*REMARK* SamacSys ECAD Model
776903/1895263/2.50/3/0/Transistor BJT NPN
