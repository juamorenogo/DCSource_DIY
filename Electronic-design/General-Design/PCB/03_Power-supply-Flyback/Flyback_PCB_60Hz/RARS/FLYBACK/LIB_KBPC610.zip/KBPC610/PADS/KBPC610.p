*PADS-LIBRARY-PART-TYPES-V9*

KBPC610 KBPC610 I ANA 7 1 0 0 0
TIMESTAMP 2026.07.26.23.43.51
"Mouser Part Number" 637-KBPC610
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Diotec-Semiconductor/KBPC610?qs=OlC7AqGiEDnk75wjX5X7wg%3D%3D
"Manufacturer_Name" Diotec
"Manufacturer_Part_Number" KBPC610
"Description" Bridge Rectifiers Bridge, single phase, KBPC6, 1000V, 6A, 150C
"Datasheet Link" https://diotec.com/request/datasheet/kbpc600.pdf
"Geometry.Height" 6.5mm
GATE 1 4 0
KBPC610
1 0 U +
2 0 U ~_1
3 0 U -
4 0 U ~_2

*END*
*REMARK* SamacSys ECAD Model
1582790/1895263/2.50/4/3/Bridge Rectifier
